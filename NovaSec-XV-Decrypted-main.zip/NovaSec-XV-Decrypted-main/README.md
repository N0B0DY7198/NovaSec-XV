Credits to [M0b0dy7198](https://github.com/N0B0DY7198/), idk if this is skidripped or not but its wtv 

I found some random ass py c2 source that imma use to figure out how to get a telnet server thread running for [fcnc](https://github.com/cloudcant/fcnc)

The normal repos Readme Content :
> This source is unfinished and does work on a small scale.
> Have fun with this source but please dont claim it as yours, Thats something only a skid would do and if you plan on stealing this please contact me first and i can ? > help you make and setup your own source and i will help you become better <3
> Please contact me on telegram to buy a custom source or buy this source code. https://t.me/NOB0DYONTOP
